=====
Django AWS SAAS
=====

Django AWS SAAS is a Django app that facilitates the creation of certificates and email identities in AWS.
