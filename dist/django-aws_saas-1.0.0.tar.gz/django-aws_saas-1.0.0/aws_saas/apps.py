from django.apps import AppConfig


class AwsAcmConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aws_saas'
